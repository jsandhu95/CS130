#include "plane.h"
#include "ray.h"
#include <cfloat>
#include <limits>

// Intersect with the half space defined by the plane.  The plane's normal
// points outside.  If the ray starts on the "inside" side of the plane, be sure
// to record a hit with t=0 as the first entry in hits.
Hit Plane::Intersection(const Ray& ray, int part) const
{
    //TODO;
    Hit intersect;
    double u;
    double t;
    vec3 X = ray.endpoint - x1;
    u = dot(ray.direction, normal);
    //does not intersect
    if(u == 0){
        intersect = {0,0,0};
    }
    else{
        t = dot(X, normal)/u;
        t = (-1) * t;
        if(t > small_t){
            intersect = {this, t, 1};
        }
        else{
            intersect = {0,0,0};
        }
    }
    return intersect;
}

vec3 Plane::Normal(const vec3& point, int part) const
{
    return normal;
}

// There is not a good answer for the bounding box of an infinite object.
// The safe thing to do is to return a box that contains everything.
Box Plane::Bounding_Box(int part) const
{
    Box b;
    b.hi.fill(std::numeric_limits<double>::max());
    b.lo=-b.hi;
    return b;
}
