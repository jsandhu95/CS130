#include "sphere.h"
#include "ray.h"

// Determine if the ray intersects with the sphere
Hit Sphere::Intersection(const Ray& ray, int part) const
{
    //TODO;
    Hit intersect;
    vec3 z = ray.endpoint - center;
    double a = ray.direction.magnitude_squared();
    double b = dot(ray.direction,z);
    b = b*2;
    double c = z.magnitude_squared() - (radius*radius);
    double r = (b*b) - (4*a*c);
    double x,y;
    if(r < 0){
        intersect = (0,0,0);
    }
    else{
        x = ((-1)*b + sqrt(root))/(2*a);
        y = ((-1)*b - sqrt(root))/(2*a);
        if(x<y && x>=small_t){
            intersect = {this,x,1};
        }
        else if(y<=x && y>=small_t){
            intersect = {this,y,1};
        }
        else{
            intersect = {0,0,0};
        }
    }
    return intersect;
}

vec3 Sphere::Normal(const vec3& point, int part) const
{
    vec3 normal;
    //TODO; // compute the normal direction
    return normal;
}

Box Sphere::Bounding_Box(int part) const
{
    Box box;
    //TODO; // calculate bounding box
    return box;
}
